<?php

class App{
    var $controller = '';
    var $method = '';
    var $params = [];

    public function __construct(){
        $url = $this->parseUrl();
        if (empty($url[1]) && empty($url[2])) {
            $url[1]="category";
            $url[2]="index";
        }
        if(isset($url[1]) && file_exists('app/controllers/' . $url[1] . 'Controller.php')){
            $this->controller = $url[1] . 'Controller';
            unset($url[1]); 
        }
        require_once  'app/controllers/' . $this->controller . '.php';
        $this->controller = new $this->controller();

        if(isset($url[2]) && method_exists($this->controller , $url[2])){
            $this->method = $url[2];
            unset($url[2]); 
        }
        $this->params = $url ? array_values($url) : [];
        array_splice($this->params, 0, 1);
        call_user_func_array([$this->controller,$this->method],$this->params);
        
    }

    public function parseUrl()
    {
        if (isset($_GET['url'])) {
            return explode('/',filter_var(rtrim($_GET['url'], '/'),FILTER_SANITIZE_URL));
        }
    }

}

?>