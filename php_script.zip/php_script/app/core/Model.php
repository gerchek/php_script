<?php

class Model{
    protected static $_connection = null;

    public function __construct()
    {

        $servername = "localhost";
        $username = "username";
        $password = "password";
        $dbname = "test";

        // Create connection
        self::$_connection = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if (self::$_connection->connect_error) {
            die("Connection failed: " . self::$_connection->connect_error);
        }

    }
}