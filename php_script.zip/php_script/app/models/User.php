<?php
class User extends Model{
    var $username;
    var $password_hash;

    public function find($user_id){
        $sql = "SELECT * FROM User WHERE id = " . $user_id ."";
        $result = self::$_connection->query($sql);
        echo($result);
        return $result->fetch_assoc();
    }

    public function findUser($username){
        $sql = "SELECT * FROM User WHERE username = '" . $username ."'";
        $result = self::$_connection->query($sql);
        return $result->fetch_assoc();
    }

    public function create(){
        $SQL = "INSERT INTO User(username, password_hash) VALUES ('$this->username', '$this->password_hash')";
        if (self::$_connection->query($SQL) === TRUE) {
            header('location:/login/index');
        } else {
            echo "Error creating user: " . self::$_connection->error;
        }
    }
}
?>