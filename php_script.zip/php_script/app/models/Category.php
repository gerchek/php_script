<?php

    class Category extends Model{
        var $name;
        static $myArray = '';

        public function getRecursive($parent_id = 0, $margin_left = 0){
            $sql = "SELECT * FROM categories WHERE parent_id = $parent_id ORDER BY name ASC";
            $result = self::$_connection->query($sql);
            if ($result->num_rows > 0) {

                while($row = $result->fetch_assoc()){
                    self::$myArray .= '<li id="'. $row['id'] .'" class="list-group-item" style="margin-left:' . $margin_left . 'px" onClick="handleDropDown(this.id)">Name: '.$row['name'].'
                        <img id="click" src="/static/images/click-here.png" >
                        <span class="is-hidden-initially">Description: '.$row['description'].'</span>
                    '. ($_SESSION['user_id'] == NULL ? ' ' : '
                    <a class="btn btn-success" href="/category/childCreate/'.$row['id'].'" role="button">Create child</a>
                    <a class="btn btn-primary" href="/category/edit/' . $row['id'] .'" role="button">Update</a>
                    <a class="btn btn-danger" href="/category/delete/' . $row['id'] .'" role="button">Delete</a>') .'
                    </li>';
                    $this->getRecursive($row['id'], $margin_left + 50);
                }

            } 
            return self::$myArray;
        }

        public function getAll(){
            $sql = "SELECT * FROM categories";
            $result = self::$_connection->query($sql);
            $arr = array();

            if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                array_push($arr, $row);
            }
            } else {
                echo "0 results";
            }
            return $arr;
        }

        public function find($item_id){
            $sql = "SELECT * FROM categories WHERE id = " . $item_id ."";
            $result = self::$_connection->query($sql);
            $arr = array();
            if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                array_push($arr, $row);
            }
            } else {
                echo "0 results";
            }
            return $arr;
        }

        public function update($theItem_id,$theItem_name,$theItem_description,$theItem_parent_id){
            $int_value = intval( $theItem_id );
            
            $sql = "UPDATE categories SET name = '$theItem_name' , description = '$theItem_description' , parent_id = '$theItem_parent_id' WHERE ID =$int_value";
            if (self::$_connection->query($sql) === TRUE) {
                header('location:/category/index');
            } else {
                echo "Error updating record: " . self::$_connection->error;
            }
        }

        public function create($theItem_name,$theItem_description,$theItem_parent_id){
            $SQL = "INSERT INTO categories(parent_id, name, description) VALUES ($theItem_parent_id, '$theItem_name', '$theItem_description')";
            // echo($SQL);
            if (self::$_connection->query($SQL) === TRUE) {
                header('location:/category/index');
            } else {
                echo "Error creating record: " . self::$_connection->error;
            }
        }

        public function delete($theItem_id){
            $request = "SELECT * FROM categories WHERE parent_id = '$theItem_id'";
            $results = self::$_connection->query($request);
            while($child = $results->fetch_assoc()) 
            {
                $this->delete($child["id"]);
            }
            $request = "DELETE FROM categories WHERE id = '$theItem_id'";
            if (self::$_connection->query($request) === TRUE) {
                header('location:/category/index');
            } else {
                echo "Error deleting record: " . self::$_connection->error;
            }
        }

    }

?>