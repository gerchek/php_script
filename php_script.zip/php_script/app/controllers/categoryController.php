<?php

    class CategoryController extends Controller{

        public function index(){
            $categories = $this->model('Category')->getRecursive();
            $this->view('category/index', ['categories' => $categories]);
        }

        public function edit($item_id){
            if($_SESSION['user_id'] == null){
                header('location:/category/index');
                return;
            }
            if(isset($_POST['action'])){
                $theItem_id = $_POST['id'];
                $theItem_name = $_POST['name'];
                $theItem_description = $_POST['description'];
                $theItem_parent_id = $_POST['parent_id'];
                $this->model('Category')->update($theItem_id,$theItem_name,$theItem_description,$theItem_parent_id);
            }
            else{
                $categories = $this->model('Category')->getAll();
                $item_data = $this->model('Category')->find($item_id);
                $this->view('category/edit',['categories' => $categories,'item_data' => $item_data]);
            }
        }

        public function childCreate($parentID=NULL){
            if($_SESSION['user_id'] == null){
                header('location:/category/index');
                return;
            }
            if(isset($_POST['action'])){
                $theItem_name = $_POST['name'];
                $theItem_description = $_POST['description'];
                $theItem_parent_id = $_POST['id'];
                $int_value = intval( $theItem_parent_id );
                $this->model('Category')->create($theItem_name,$theItem_description,$int_value);
                header('location:/category/index');
            }else{
                $categories = $this->model('Category')->getAll();
                $this->view('category/create',['parentID' => $parentID,'categories' => $categories]);
            }
        }

        public function delete($item_id){
            if($_SESSION['user_id'] == null){
                header('location:/category/index');
                return;
            }
            $this->model('Category')->delete($item_id);
        }
    }
?>