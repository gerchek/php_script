<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create an item</title>
    <link rel="stylesheet" href="/static/main.css">
</head>
<body>
    <h1>Register</h1>
    <?php
        if (!is_array($data)) {
            echo $data;
        }
    ?>


    <form method="post" id="login_form">
        <label for="fname">Username</label>
        <input type="text" id="fname" name="username" placeholder="Your username..">

        <label for="lname">Password</label>
        <input type="password" id="lname" name="password" placeholder="Your password..">

        <label for="lname">Re-enter your password</label>
        <input type="password" id="lname" name="password_confirm" placeholder="Re-enter your password..">

        <input type="submit" name="action" value="Register">
    </form>
    Already have an account? <a href="/login/index">Login</a>

</body>
</html>