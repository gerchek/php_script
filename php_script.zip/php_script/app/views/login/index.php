<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create an item</title>
    <link rel="stylesheet" href="/static/main.css">
</head>
<body>
    <h1>Login</h1>
    <?php
        if (!is_array($data)) {
            echo $data;
        }
    ?>


    <form method="post" id="login_form">
        <label for="fname">Username</label>
        <input type="text" id="fname" name="username" placeholder="Your username..">

        <label for="lname">Password</label>
        <input type="password" id="lname" name="password" placeholder="Your password..">

        <input type="submit" name="action" value="Login">
    </form>
    No account? <a href="/login/register">Register</a>
</body>
</html>