<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit an item</title>
    <link rel="stylesheet" href="/static/main.css">
</head>
<body>
    <h1>Create an item</h1>

    <form method="post" style="width: 70%;margin: auto;" id="myForm">

        <div class="container">
            <label for="uname"><b>Username</b></label>
            <input type="text" placeholder=" <?=$data['item_data'][0]['name'] ?> " name="name" required>
            <label for="uname"><b>Description</b></label>
            <input type="text" placeholder=" <?=$data['item_data'][0]['description'] ?> " name="description" required>
            
            <?php
                if ($data['parentID']) {
                    echo  '<input type="hidden" name="id" value='.$data['parentID'].'>';
                }else{
                    echo('<div class="custom-select" style="width:200px;"><select name="parent_id"><option value="0">NO PARENT</option>');
                            foreach($data['categories'] as $item){
                                echo '<option value='. $item['id'] .'>' . $item['name'] . '</option>';
                            }
                    echo('</select></div>');
                }
            ?>
            <input type="submit" name="action" value="Create">
        </div>

        <div class="container" style="background-color:#f1f1f1">
            <a href="/category/index" class="cancelbtn">Cancel</a>
        </div>
    </form>


    <script src="/static/main.js"></script>
</body>
</html>