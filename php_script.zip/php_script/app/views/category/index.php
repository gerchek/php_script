<!DOCTYPE html>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/static/main.css">
    <title>Category list</title>
</head>
<body>
<ol>
<div class="container">
    
    <?php
    if($_SESSION['user_id'] == NULL){
        echo('<h2>Page for users </h2><a href="/login/index" style="font-size: 20px;">Login</a><br>');
    }else{
        echo('<h2>Page for admins </h2><a href="/login/logout" style="font-size: 20px;">Log out</a><br>');
    }
    ?>
    <ul class="list-group">
           <?=$data['categories'] ?>
    </ul>
    <?php
    if($_SESSION['user_id'] == NULL){
        echo('');
    }else{
        echo('<li class="list-group-item"><a class="btn btn-success" href="/category/childCreate/" role="button" style="display: block;">Create new category</a></li>');
    }
    ?>
    <script src="/static/main.js"></script>
</div>
</body>
</html>

